## Little Lemon

### By Yaroslav Yurev, August 18th, 2023
This is the code project submission for the newsletter subscription app assignment.

![](little_lemon.gif)
